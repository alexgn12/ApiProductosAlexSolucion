export interface Producto {
  productId: number;
  name: string;
  category: string;
  price: number;
  fecha: string; // o Date si el backend lo envía como ISO
  stock: number;
}
import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ProductService {
  private apiUrl = 'https://localhost:7291/api/Products';

  constructor(private http: HttpClient) {}

  getProducts(params?: {
    pageNumber?: number;
    pageSize?: number;
    name?: string;
    category?: string;
    stock?: number;
    createdDate?: string;
  }): Observable<{ products: Producto[]; totalCount: number }> {
    let httpParams = new HttpParams();
    if (params) {
      if (params.pageNumber !== undefined) {
        httpParams = httpParams.set('pageNumber', params.pageNumber.toString());
      }
      if (params.pageSize !== undefined) {
        httpParams = httpParams.set('pageSize', params.pageSize.toString());
      }
      if (params.name) {
        httpParams = httpParams.set('name', params.name);
      }
      if (params.category) {
        httpParams = httpParams.set('category', params.category);
      }
    }
    return this.http.get<{ totalCount: number; products: Producto[] }>(this.apiUrl, { params: httpParams });
  }

  getProductById(id: number): Observable<Producto> {
    return this.http.get<Producto>(`${this.apiUrl}/${id}`);
  }

}
