import { Routes } from '@angular/router';

import { ProductListComponent } from './product-list/product-list';
import { ProductDetalleComponent } from './product-detalle/product-detalle';

export const routes: Routes = [
	{ path: '', component: ProductListComponent },
	{ path: 'producto/:id', component: ProductDetalleComponent },
];
