import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ProductService, Producto } from '../product.service';

@Component({
  selector: 'app-product-detalle',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './product-detalle.html',
  styleUrl: './product-detalle.css'
})
export class ProductDetalleComponent implements OnInit {
  producto?: Producto;
  cargando = true;
  error?: string;

  constructor(private route: ActivatedRoute, private productService: ProductService) {}

  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    if (id) {
      this.productService.getProductById(id).subscribe({
        next: (prod) => {
          this.producto = prod;
          this.cargando = false;
        },
        error: (err) => {
          this.error = 'No se pudo cargar el producto';
          this.cargando = false;
        }
      });
    } else {
      this.error = 'ID de producto inválido';
      this.cargando = false;
    }
  }
}
