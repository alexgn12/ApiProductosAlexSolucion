import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductDetalleComponent } from './product-detalle';

describe('ProductDetalleComponent', () => {
  let component: ProductDetalleComponent;
  let fixture: ComponentFixture<ProductDetalleComponent>;

  beforeEach(async () => {
  await TestBed.configureTestingModule({
        declarations: [ProductDetalleComponent]
      })
      .compileComponents();
  
      fixture = TestBed.createComponent(ProductDetalleComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
