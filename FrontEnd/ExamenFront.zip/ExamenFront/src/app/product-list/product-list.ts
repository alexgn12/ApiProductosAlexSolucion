import { Component, OnInit } from '@angular/core';
import { ProductService, Producto } from '../product.service';
import { CommonModule, CurrencyPipe } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';



@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.html',
  styleUrls: ['./product-list.css'],
  standalone: true,
  imports: [CommonModule, FormsModule, CurrencyPipe, RouterModule]
})
export class ProductListComponent implements OnInit {
  stock?: number;
  products: Producto[] = [];
  totalCount: number = 0;
  name: string = '';
  category: string = '';
  pageNumber: number = 1;
  pageSize: number = 10;
  totalPages: number = 1;

  constructor(private productService: ProductService) {}

  ngOnInit(): void {
    this.loadProducts();
  }

  loadProducts(): void {
    this.productService.getProducts({
      pageNumber: this.pageNumber,
      pageSize: this.pageSize,
      name: this.name,
      category: this.category
    }).subscribe({
      next: (resp) => {
        this.products = resp.products;
        this.totalCount = resp.totalCount;
        this.totalPages = this.totalCount > 0 ? Math.ceil(this.totalCount / this.pageSize) : 1;
      }
    });
  }

  buscar(): void {
    this.pageNumber = 1;
    this.loadProducts();
  }

  resetFiltros(): void {
    this.name = '';
    this.category = '';
    this.stock = undefined;
    this.pageNumber = 1;
    this.loadProducts();
  }

  paginaSiguiente(): void {
    if ((this.pageNumber * this.pageSize) < this.totalCount) {
      this.pageNumber++;
      this.loadProducts();
    }
  }

  paginaAnterior(): void {
    if (this.pageNumber > 1) {
      this.pageNumber--;
      this.loadProducts();
    }
  }

  irPrimeraPagina(): void {
    if (this.pageNumber !== 1) {
      this.pageNumber = 1;
      this.loadProducts();
    }
  }

  irUltimaPagina(): void {
    if (this.pageNumber !== this.totalPages) {
      this.pageNumber = this.totalPages;
      this.loadProducts();
    }
  }
}
